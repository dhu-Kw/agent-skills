"""Synthetic fixtures only; never packages real invoices or passenger data."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from datetime import date
from decimal import Decimal

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont

SPEC = importlib.util.spec_from_file_location('extract', Path(__file__).parents[1] / 'scripts' / 'extract_trips.py')
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))


def fixture(path, gaode=False, pages=1, total=None, amount='12.34', blank_origin=False):
    c = canvas.Canvas(str(path), pagesize=(1100, 800))
    for page in range(pages):
        c.setFont('STSong-Light', 12)
        c.drawString(30, 760, '高德地图—打车——行程单' if gaode else '滴滴出行-行程单')
        if page == 0:
            c.drawString(30, 730, '行程时间：2026-08-01 08:00至2026-08-03 20:00' if gaode else '行程起止日期：2026-08-01 至 2026-08-03')
            c.drawString(30, 710, f'共计{pages}单行程，合计{total or str(Decimal(amount) * pages)}元' if gaode else f'共{pages}笔行程，合计{total or str(Decimal(amount) * pages)}元')
        labels = ['序号', '服务商', '车型', '上车时间', '城市', '起点', '终点', '金额']
        widths = [45, 75, 70, 160, 70, 260, 260, 80]
        xs = [20]
        for w in widths:
            xs.append(xs[-1] + w)
        for y in [660, 620, 540]:
            c.line(xs[0], y, xs[-1], y)
        for x in xs:
            c.line(x, 620 if gaode and x not in (xs[0], xs[-1]) else 540, x, 660)
        for x, label in zip(xs, labels):
            c.drawString(x + 4, 635, label)
        values = [str(page + 1), '合成服务商', '经济型', f"{'2026-' if gaode else ''}08-0{page+1} 08:31", '测试市',
                  '' if blank_origin else '示例路|华源上海城-东北门', '测试区|示例产业中心有限\n公司-东北门', amount + ('元' if gaode else '')]
        for x, value in zip(xs, values):
            for offset, line in enumerate(value.split('\n')):
                c.drawString(x + 4, 588 - offset * 16, line)
        c.showPage()
    c.save()


class ExtractionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=os.environ.get('TRAVEL_TEST_TMP'))
        self.base = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def result(self, **kwargs):
        path = self.base / 'synthetic.pdf'
        fixture(path, **kwargs)
        return mod.run_manifest({'files': [{'path': path.name, 'invoice_number': '12345678901234567890'}]}, self.base)

    def test_didi_cross_page(self):
        r = self.result(pages=2)
        self.assertTrue(r['local_checks_passed'], r['issues'])
        self.assertEqual([x['page'] for x in r['rows']], [1, 2])
        self.assertEqual(r['total'], '24.68')
        self.assertEqual(r['rows'][0]['origin'], '华源上海城')
        self.assertEqual(r['rows'][0]['destination'], '测试区|示例产业中心有限公司-东北门')

    def test_gaode_merged_body(self):
        r = self.result(gaode=True)
        self.assertTrue(r['local_checks_passed'], r['issues'])
        self.assertEqual(r['rows'][0]['date'], '2026-08-01')
        self.assertEqual(r['rows'][0]['amount'], '12.34')

    def test_total_mismatch(self):
        r = self.result(total='99.00')
        self.assertIn('total_mismatch', [i['code'] for i in r['issues']])

    def test_missing_address_blocks(self):
        r = self.result(blank_origin=True)
        self.assertFalse(r['local_checks_passed'])
        self.assertIn('row_parse', [i['code'] for i in r['issues']])

    def test_invoice_is_required_string(self):
        path = self.base / 'a.pdf'
        fixture(path)
        for inv in (None, 12345, ''):
            r = mod.run_manifest({'files': [{'path': 'a.pdf', 'invoice_number': inv}]}, self.base)
            self.assertFalse(r['local_checks_passed'])
            self.assertEqual(len(r['rows']), 1)
            self.assertIsNone(r['rows'][0]['invoice_number'])

    def test_duplicate_preserved(self):
        path = self.base / 'a.pdf'
        fixture(path)
        r = mod.run_manifest({'files': [{'path': 'a.pdf', 'invoice_number': '123'}] * 2}, self.base)
        self.assertEqual(len(r['rows']), 2)
        self.assertIn('duplicate', [i['code'] for i in r['issues']])

    def test_same_invoice_aggregate_balance(self):
        path = self.base / 'a.pdf'
        fixture(path)
        r = mod.run_manifest({'files': [{'path': 'a.pdf', 'invoice_number': '123'}] * 2,
                              'available_by_invoice': {'123': '20.00'}}, self.base)
        self.assertEqual(r['invoice_totals']['123'], '24.68')
        self.assertIn('insufficient_balance', [i['code'] for i in r['issues']])

    def test_zero_balance(self):
        r = self.result()
        result = mod.assemble([(r['rows'], r['files'][0])], [], {'12345678901234567890': '0.00'})
        self.assertEqual(result['issues'][0]['code'], 'insufficient_balance')

    def test_unknown_balance(self):
        r = self.result()
        result = mod.assemble([(r['rows'], r['files'][0])], [], {})
        self.assertEqual(result['issues'][0]['code'], 'balance_unknown')

    def test_sort_keeps_source(self):
        r = self.result(pages=2)
        result = mod.assemble([(list(reversed(r['rows'])), r['files'][0])], [])
        self.assertEqual([x['source_sequence'] for x in result['rows']], [1, 2])

    def test_money_no_rounding_or_guessing(self):
        for s in ('', '-1', '1.234', '1O.20', 'NaN', '0'):
            with self.assertRaises(ValueError):
                mod.money(s)
        self.assertEqual(str(mod.money('44.53元')), '44.53')

    def test_year_from_cross_year_range(self):
        self.assertEqual(mod.parse_stamp('01-02 09:00', date(2025, 12, 30), date(2026, 1, 3))[0], '2026-01-02')

    def test_ambiguous_year_blocks(self):
        with self.assertRaises(ValueError):
            mod.parse_stamp('01-02 09:00', date(2025, 1, 1), date(2026, 12, 31))

    def test_out_of_range_blocks(self):
        with self.assertRaises(ValueError):
            mod.parse_stamp('2024-01-02 09:00', date(2026, 1, 1), date(2026, 12, 31))

    def test_missing_file_blocks(self):
        r = mod.run_manifest({'files': [{'path': 'missing.pdf', 'invoice_number': '123'}]}, self.base)
        self.assertFalse(r['local_checks_passed'])
        self.assertEqual(r['rows'], [])

    def test_invoice_not_itinerary(self):
        with self.assertRaises(ValueError):
            mod.metadata('电子发票（普通发票） 滴滴出行科技有限公司 价税合计 12.34')

    def test_address_rule_does_not_shorten_others(self):
        self.assertEqual(mod.short_address('甲区|完整道路(东门)'), '甲区|完整道路(东门)')

    def test_preview_not_browser_authorization(self):
        r = self.result()
        content = mod.preview(r)
        self.assertIn('待用户确认', content)
        self.assertIn('未执行', r['webpage_checks'])


if __name__ == '__main__':
    unittest.main()
