# 提取接口

运行需要 Python 3.10+ 与 pdfplumber。优先使用宿主提供的 Python/PDF 依赖，不能假定命令 `python` 指向可运行解释器。缺失时说明并按安装环境处理。

准备本次任务专用的 UTF-8 JSON manifest（放在技能包外）：

```json
{"files": [{"path": "D:/报销/滴滴_行程单.pdf", "invoice_number": "完整发票号"}]}
```

invoice_number 必须为字符串；未知可为 null，此时仍产出预览，但标记阻塞，不允许填网页。相对文件路径相对 manifest 所在目录解析。不是从文件名猜发票号。

```text
python scripts/extract_trips.py --manifest INPUT.json --output OUTPUT.json --preview PREVIEW.md
```

输出含 rows、files、invoice_totals、total、issues、local_checks_passed；每行保留 date/time、原始和填写地址、amount、invoice_number、source_file/page/source_sequence。退出码 0 表示本地检查通过，2 表示存在需处理问题，1 表示命令级故障。本地通过不等于允许操作网页：仍须核对网页发票、余额、已有内容并得到用户对清单的确认。

金额解析不允许悄悄四舍五入、修正负数、填补缺失。跨年缺少年份时枚举行程范围内候选日期，仅唯一时接受。使用表头列位置裁剪单元格，可读取样本中无内部竖线的高德数据行；不支持的版式以缺失/笔数/序号校验阻塞，不能臆造行程。

保留原地址用于查重，另对简化后相同的记录做疑似重复提示。issues 中的错误或重复需要用户处理后重建清单；不能删除提示字段就声称校验通过。用户明确保留真实重复时记录该决定，其他校验仍须通过。

如需校验网页发票可用金额，可在 manifest 增加 `available_by_invoice`（发票号到十进制字符串的映射），值必须来自本次页面真实观察；未提供时输出明确提示网页检查仍未执行，不能猜余额。不同文件映射同一发票时按分组合计比较。
