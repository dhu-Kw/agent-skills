# 安装与使用

把整个 `fill-travel-reimbursement` 文件夹放入 Codex 的 `$CODEX_HOME/skills`；未设置 CODEX_HOME 时使用 `%USERPROFILE%\.codex\skills`。保留原目录结构，已有同名技能时先比较版本，不直接覆盖个人修改。重新打开客户端或新建会话后检查技能是否被发现。

Windows Chrome/Edge 的网页填写还需要宿主可用的浏览器或电脑控制工具。Skill 文件本身不提供浏览器连接、登录或 VPN。缺少 UI 能力时只能提取和展示清单。Codex 中如有 computer-use 插件，按其说明操作；不写死某个用户电脑的工具路径。

提取依赖 Python 3.10+、pdfplumber；测试另需 reportlab。优先使用客户端自带运行时。没有时可在已有 Python 环境运行 `python -m pip install pdfplumber`，开发测试再安装 reportlab。

使用示例：
> 使用 $fill-travel-reimbursement，处理这两份行程单。文件 A 对应发票号……，文件 B 对应发票号……。先合并展示清单，等我确认后填写当前打开的报销单。

用户需提前登录内网报销系统、打开目标单、上传发票。清单确认后如发现已有行程，选择清空或保留；完成后检查首行费用归属并自行保存/提交。

WorkBuddy：待验证。需要在实际版本中验证技能导入、Python/PDF 依赖、Chrome/Edge 已登录会话控制和停在待审核状态，不能据 Codex 测试结果声称兼容。其他客户端同样待验证。

包内仅含指令、代码和合成测试，不含真实 PDF、手机号、发票号、报销单编号或登录信息。输出清单保存在用户指定的本次任务目录，不放回分享包。
