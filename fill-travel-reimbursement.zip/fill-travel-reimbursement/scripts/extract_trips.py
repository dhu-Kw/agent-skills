"""Read-only itinerary extraction. No browser, network, or reimbursement writes."""
import argparse
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import re


def clean(value):
    return ''.join(str(value or '').splitlines()).strip()


def money(value):
    s = str(value).strip().replace('元', '').replace('¥', '').replace('￥', '').strip()
    if not re.fullmatch(r'\d+(?:\.\d{1,2})?', s):
        raise ValueError('金额缺失或格式不支持: ' + s)
    n = Decimal(s)
    if n <= 0:
        raise ValueError('金额必须大于零: ' + s)
    return n.quantize(Decimal('0.01'))


def short_address(value):
    value = clean(value)
    if not value:
        raise ValueError('地址缺失')
    return '华源上海城' if '华源上海城' in value else value


def parse_stamp(value, start, end):
    m = re.search(r'(?:(\d{4})-)?(\d{2})-(\d{2})\s+(\d{2}:\d{2})', value)
    if not m:
        raise ValueError('乘车日期或时间无法识别: ' + value)
    year, month, day, time = m.groups()
    datetime.strptime(time, '%H:%M')
    candidates = []
    for y in ([int(year)] if year else range(start.year, end.year + 1)):
        try:
            d = date(y, int(month), int(day))
        except ValueError:
            continue
        if start <= d <= end:
            candidates.append(d)
    if len(candidates) != 1:
        raise ValueError('年份不唯一或日期超出行程范围: ' + value)
    return candidates[0].isoformat(), time


def issue(issues, code, message, **context):
    issues.append(dict(code=code, message=message, **context))


def metadata(text):
    if '滴滴出行' in text and '行程单' in text:
        provider = '滴滴'
    elif '高德' in text and '行程单' in text:
        provider = '高德'
    else:
        raise ValueError('不是已支持的滴滴/高德行程单，不能把发票当作明细')
    period = re.search(r'行程(?:起止日期|时间)\s*[：:]\s*(\d{4}-\d{2}-\d{2})(?:\s+\d{2}:\d{2})?\s*至\s*(\d{4}-\d{2}-\d{2})', text)
    count = re.search(r'共(?:计)?\s*(\d+)\s*(?:笔|单)行程', text)
    total = re.search(r'合计\s*([\d.]+)\s*元', text)
    if not all((period, count, total)):
        raise ValueError('缺少可核对的行程范围、笔数或合计；扫描件/其他版式需人工核对')
    start, end = map(date.fromisoformat, period.groups())
    if start > end:
        raise ValueError('行程日期范围倒置')
    return provider, start, end, int(count.group(1)), money(total.group(1))


def table_records(page):
    """Crop by header geometry, including AMAP rows with merged PDF cells."""
    for table in page.find_tables():
        if not table.rows:
            continue
        header = table.extract()[0]
        labels = [clean(x) for x in header]
        required = ['序号', '上车时间', '起点', '终点']
        if not all(k in labels for k in required):
            continue
        amount_cols = [i for i, s in enumerate(labels) if s.startswith('金额')]
        if len(amount_cols) != 1:
            continue
        indices = {k: labels.index(k) for k in required}
        indices['金额'] = amount_cols[0]
        cells = table.rows[0].cells
        top = table.rows[0].bbox[3]
        bottom = table.bbox[3]
        serial_cell = cells[indices['序号']]
        serial_words = page.crop((serial_cell[0], top, serial_cell[2], bottom)).extract_words()
        anchors = [w for w in serial_words if re.fullmatch(r'\d+', w['text'])]
        centers = [(w['top'] + w['bottom']) / 2 for w in anchors]
        bounds = [top] + [(a + b) / 2 for a, b in zip(centers, centers[1:])] + [bottom]
        for i, anchor in enumerate(anchors):
            record = {'序号': anchor['text']}
            for key, col in indices.items():
                if key == '序号':
                    continue
                cell = cells[col]
                box = (cell[0], bounds[i], cell[2], bounds[i + 1])
                record[key] = page.crop(box).extract_text() or ''
            yield record


def extract_file(path, invoice_number, issues):
    import pdfplumber
    rows = []
    info = {'source_file': str(path), 'invoice_number': invoice_number}
    if invoice_number not in (None, '') and (not isinstance(invoice_number, str) or not re.fullmatch(r'\d+', invoice_number)):
        issue(issues, 'invoice_mapping', '需用户提供完整发票号字符串', source_file=str(path))
        invoice_number = None
        info['invoice_number'] = None
    try:
        with pdfplumber.open(path) as pdf:
            text = '\n'.join(p.extract_text() or '' for p in pdf.pages)
            provider, start, end, count, total = metadata(text)
            info.update(provider=provider, expected_count=count, expected_total=str(total))
            for page_no, page in enumerate(pdf.pages, 1):
                for raw in table_records(page):
                    seq = int(raw['序号'])
                    try:
                        d, t = parse_stamp(raw['上车时间'], start, end)
                        origin, destination = clean(raw['起点']), clean(raw['终点'])
                        row = dict(date=d, time=t, origin=short_address(origin),
                                   destination=short_address(destination), raw_origin=origin,
                                   raw_destination=destination, amount=str(money(clean(raw['金额']))),
                                   invoice_number=invoice_number, transport='网约车', attribution='同上',
                                   source_file=str(path), page=page_no, source_sequence=seq)
                        rows.append(row)
                    except (ValueError, InvalidOperation) as exc:
                        issue(issues, 'row_parse', str(exc), source_file=str(path), page=page_no, source_sequence=seq)
            actual = sum((Decimal(r['amount']) for r in rows), Decimal('0.00'))
            info.update(extracted_count=len(rows), extracted_total=str(actual))
            if len(rows) != count:
                issue(issues, 'count_mismatch', f'表头 {count} 笔，提取 {len(rows)} 笔', source_file=str(path))
            if sorted(r['source_sequence'] for r in rows) != list(range(1, count + 1)):
                issue(issues, 'sequence_mismatch', '行程序号缺失、重复或不连续，需核对原文', source_file=str(path))
            if actual != total:
                issue(issues, 'total_mismatch', f'表头 {total}，提取合计 {actual}', source_file=str(path))
    except Exception as exc:
        # Still return partial rows for diagnosis, always blocking subsequent filling.
        issue(issues, 'file_parse', f'{type(exc).__name__}: {exc}', source_file=str(path))
    return rows, info


def assemble(file_results, issues, available=None):
    rows = [row for part, _ in file_results for row in part]
    rows.sort(key=lambda r: (r['date'], r['time']))
    raw_seen, fill_seen = {}, {}
    totals = defaultdict(lambda: Decimal('0.00'))
    for number, row in enumerate(rows, 1):
        row['list_number'] = number
        raw_key = tuple(row[k] for k in ('date', 'time', 'raw_origin', 'raw_destination', 'amount'))
        fill_key = tuple(row[k] for k in ('date', 'time', 'origin', 'destination', 'amount'))
        if raw_key in raw_seen:
            issue(issues, 'duplicate', '疑似重复，未经用户确认不删除', rows=[raw_seen[raw_key], number])
        elif fill_key in fill_seen:
            issue(issues, 'normalized_duplicate', '地址简化后相同，需核对但不能认定重复', rows=[fill_seen[fill_key], number])
        raw_seen[raw_key], fill_seen[fill_key] = number, number
        if row['invoice_number']:
            totals[row['invoice_number']] += Decimal(row['amount'])
    if available is not None:
        for invoice, total in totals.items():
            try:
                value = available[invoice]
                if not isinstance(value, str) or not re.fullmatch(r'\d+(?:\.\d{1,2})?', value):
                    raise ValueError('余额需为非负十进制字符串')
                balance = Decimal(value)
                if total > balance:
                    issue(issues, 'insufficient_balance', f'待填 {total} 超过剩余可用 {balance}', invoice_number=invoice)
            except (KeyError, ValueError, InvalidOperation) as exc:
                issue(issues, 'balance_unknown', '无法校验网页发票余额: ' + str(exc), invoice_number=invoice)
    return dict(rows=rows, files=[info for _, info in file_results],
                invoice_totals={k: str(v) for k, v in totals.items()},
                total=str(sum((Decimal(r['amount']) for r in rows), Decimal('0.00'))),
                issues=issues, local_checks_passed=not issues,
                webpage_checks='未执行：仍需核对网页发票及已有内容',
                balance_check='已按输入余额检查；填写前需核对时效' if available is not None else '未执行',
                user_confirmation='待用户确认最终清单，不能据本地通过直接填写')


def read_mapping(path):
    """Strict XLSX mapping; never convert numeric invoice cells to strings."""
    if not path.exists():
        return {}
    from openpyxl import load_workbook
    book = load_workbook(path, read_only=True, data_only=False)
    try:
        sheet = book['对应关系'] if '对应关系' in book.sheetnames else book.worksheets[0]
        rows = sheet.iter_rows()
        headers = [str(c.value or '').strip() for c in next(rows)]
        if any(headers.count(k) != 1 for k in ('行程单文件名', '发票号')):
            raise ValueError('Excel 需唯一的行程单文件名、发票号两列')
        mapping = {}
        for row in rows:
            name, invoice = [row[headers.index(k)] for k in ('行程单文件名', '发票号')]
            if name.value is None and invoice.value is None:
                continue
            if not isinstance(name.value, str) or name.data_type == 'f':
                raise ValueError('行程单文件名必须为文本')
            key = name.value.strip()
            if not key or '/' in key or '\\' in key:
                raise ValueError('行程单文件名须为完整文件名，不含目录')
            value = invoice.value
            if value not in (None, '') and (invoice.data_type == 'f' or not isinstance(value, str) or not re.fullmatch(r'[0-9]+', value.strip())):
                raise ValueError('发票号必须以文本保存完整数字，不接受数值或公式单元格')
            value = value.strip() if value else None
            if key in mapping and mapping[key] != value:
                raise ValueError('同一行程单存在冲突映射: ' + key)
            mapping[key] = value
        return mapping
    finally:
        book.close()


def run_manifest(manifest, base):
    issues, results = [], []
    files = manifest.get('files')
    if not isinstance(files, list) or not files:
        raise ValueError('manifest.files 必须是非空数组')
    mapping = None
    if 'invoice_excel' in manifest:
        config = Path(manifest['invoice_excel'])
        try:
            mapping = read_mapping(base / config)
        except Exception as exc:
            issue(issues, 'excel_mapping', str(exc))
            mapping = {}
    for item in files:
        path = Path(item['path'])
        if not path.is_absolute():
            path = base / path
        invoice = mapping.get(path.name) if mapping is not None else item.get('invoice_number')
        results.append(extract_file(path.resolve(), invoice or None, issues))
    return assemble(results, issues, manifest.get('available_by_invoice'))


def preview(result):
    def escape(s):
        return str(s).replace('|', '\\|').replace('\n', ' ')
    lines = ['# 待确认行程清单', '', '交通方式：网约车；费用归属：同上（包括首行）；其他非必要字段不填。', '',
             '|行|日期|时间（仅排序）|起点|终点|金额|发票号|来源 / 原序号 / 页|',
             '|---|---|---|---|---|---|---|---|']
    for r in result['rows']:
        source = f"{Path(r['source_file']).name} / {r['source_sequence']} / {r['page']}"
        values = [r['list_number'], r['date'], r['time'], r['origin'], r['destination'], r['amount'], r['invoice_number'] or '跳过发票选择', source]
        lines.append('| ' + ' | '.join(escape(x) for x in values) + ' |')
    lines += ['', f"共 {len(result['rows'])} 笔，合计 {result['total']} 元。", '', '## 文件小计', '']
    for f in result['files']:
        lines.append(f"- {escape(Path(f['source_file']).name)}：{f.get('extracted_count', 0)} 笔，{f.get('extracted_total', '未提取')} 元；表头 {f.get('expected_count', '?')} 笔 / {f.get('expected_total', '?')} 元。")
    lines += ['', '## 发票分组合计', '']
    lines += [f'- {k}：{v} 元' for k, v in result['invoice_totals'].items()] or ['- 无发票映射，仅填写行程信息。']
    lines += ['', '## 需处理的问题', '']
    lines += [f"- {escape(json.dumps(x, ensure_ascii=False))}" for x in result['issues']] or ['- 本地校验未发现差异。']
    lines += ['', result['webpage_checks'], result['user_confirmation'], '', '填完后需人工调整首行费用归属；不点击保存、提交或下一步。', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--preview', type=Path)
    args = parser.parse_args()
    inputs = json.loads(args.manifest.read_text(encoding='utf-8-sig'))
    protected = {args.manifest.resolve()}
    if inputs.get('invoice_excel'):
        protected.add((args.manifest.parent / inputs['invoice_excel']).resolve())
    for f in inputs.get('files', []):
        p = Path(f['path'])
        protected.add((args.manifest.parent / p).resolve())
    outputs = [p.resolve() for p in (args.output, args.preview) if p is not None]
    if len(set(outputs)) != len(outputs) or any(p in protected for p in outputs):
        raise ValueError('输出不能覆盖输入文件，JSON 和预览路径必须不同')
    result = run_manifest(inputs, args.manifest.parent)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    if args.preview:
        args.preview.parent.mkdir(parents=True, exist_ok=True)
        args.preview.write_text(preview(result), encoding='utf-8')
    print(json.dumps({'rows': len(result['rows']), 'total': result['total'], 'issues': len(result['issues']), 'local_checks_passed': result['local_checks_passed']}, ensure_ascii=False))
    return 0 if result['local_checks_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
